﻿using CybersecurityChatbot;
using System;

namespace CyberSecurityChatBot
{
    /// <summary>
    /// Handles the user session by asking for the user's name
    /// and displaying a personalised welcome message.
    /// </summary>
    class UserSession
    {
        public string UserName { get; private set; }

        // Asks the user to enter their name and validates the input
        // Then shows a personalised greeting message

        public void StartSession()
        {
            ConsoleHelper.PrintDivider();

            ConsoleHelper.TypeLine(" Welcome to your Cybersecurity Awareness Assistant! ", ConsoleColor.Green);

            ConsoleHelper.TypeLine(" I am here to help you stay safe online. ", ConsoleColor.Green);

            ConsoleHelper.PrintDivider();
            Console.WriteLine();

            UserName = PromptForName();

            Console.WriteLine();

            ConsoleHelper.TypeLine($" Hello, {UserName}! Great to have you here. 😊", ConsoleColor.Cyan);

            ConsoleHelper.TypeLine(" I will guide you on how to protect yourself from cyber threats. ", ConsoleColor.Cyan);
            Console.WriteLine();
        }

        // Keeps asking the user for their name until a valid (non-empty) input is provided
        private string PromptForName()
        {
            string name;
            do
            {
                Console.ForegroundColor = ConsoleColor.Yellow;

                Console.WriteLine(" >> Please enter your name: ");

                Console.ResetColor();

                name = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(name))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("  ⚠  Name cannot be empty. Please enter your name.");
                    Console.ResetColor();
                }

            } while (string.IsNullOrWhiteSpace(name));

            return name.Trim();
        }
    }
}