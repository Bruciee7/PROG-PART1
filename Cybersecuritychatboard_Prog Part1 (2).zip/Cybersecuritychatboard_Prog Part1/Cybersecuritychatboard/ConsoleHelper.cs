﻿using System;
using System.Threading;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Contains helper methods for console output, including colours,
    /// typing effects, dividers, and formatted messages.
    /// </summary>
    static class ConsoleHelper
    {
        /// <summary>
        /// Displays text with a typing animation, printing one character at a time.
        /// </summary>
        public static void TypeLine(string text, ConsoleColor color, int delayMs = 20)
        {
            Console.ForegroundColor = color;
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(delayMs);
            }
            Console.WriteLine();
            Console.ResetColor();
        }

        /// <summary>
        /// Displays a chatbot response with a prefix and typing effect.
        /// </summary>
        public static void PrintBotResponse(string message, ConsoleColor color)
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("  [CyberBot] >> ");
            Console.ForegroundColor = color;

            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(12);
            }

            Console.WriteLine();
            Console.ResetColor();
        }

        /// <summary>
        /// Prints a styled horizontal divider line to separate sections.
        /// </summary>
        public static void PrintDivider()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("  ══════════════════════════════════════════════════════");
            Console.ResetColor();
        }
    }
}