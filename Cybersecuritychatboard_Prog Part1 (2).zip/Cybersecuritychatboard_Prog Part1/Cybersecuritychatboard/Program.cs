﻿using System;

namespace CyberSecurityChatBot
{
    /// <summary>
    /// Entry point of the CyberSecurityChatBot application.
    /// Coordinates the startup process by calling different classes.
    /// </summary>
    internal class Program
    {
        static void Main(string[] args)
        {
            // Sets console output encoding to support special characters and emojis
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Step 1: Plays a voice greeting using text-to-speech
            VoiceGreeting.Play();

            // Step 2: Displays the ASCII art logo and application header
            AsciiArt.Display(); 

            // Step 3: Captures the user's name and displays a personalised welcome message
            UserSession session = new UserSession();
            session.StartSession();

            // Final Step: Starts the main chatbot interaction loop
            ChatBot bot = new ChatBot(session.UserName);
            bot.Run();
        }
    }
}