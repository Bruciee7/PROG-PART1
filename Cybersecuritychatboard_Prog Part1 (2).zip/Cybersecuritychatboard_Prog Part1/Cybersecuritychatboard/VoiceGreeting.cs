﻿using System;
using System.Speech.Synthesis;

namespace CyberSecurityChatBot
{
    /// <summary>
    /// Provides functionality to play a spoken greeting when the application starts.
    /// Uses text-to-speech to deliver a welcome message to the user.
    /// </summary>
    static class VoiceGreeting
    {
        /// <summary>
        /// Initializes the speech synthesizer and plays the greeting message.
        /// </summary>
        public static void Play()
        {
            try
            {
                // Create and manage the speech synthesizer instance
                using (SpeechSynthesizer synthesizer = new SpeechSynthesizer())
                {
                    // Configure audio output settings
                    synthesizer.Volume = 100; // Sets volume level (range: 0–100)
                    synthesizer.Rate = 0;     // Sets speech speed (range: -10 to 10)

                    // Select a neutral voice for the greeting
                    synthesizer.SelectVoiceByHints(VoiceGender.Neutral);

                    // Speak the welcome message synchronously
                    synthesizer.Speak(
                        "Hello! Welcome to the Cybersecurity awareness assistant. " +
                        "I am here to help you stay safe online. Let's get started!"
                    );
                }
            }
            catch (Exception ex)
            {
                // Capture and log any errors without interrupting the application
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }
    }
}