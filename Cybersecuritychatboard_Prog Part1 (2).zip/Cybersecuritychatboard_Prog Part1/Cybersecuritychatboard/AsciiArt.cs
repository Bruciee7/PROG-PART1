﻿using System;
using System.Drawing;
using System.IO;
using System.Security.Policy;
using System.Text;

namespace CyberSecurityChatBot
{
    /// <summary>
    /// Converts an image into ASCII art and displays it in the console.
    /// </summary>
    static class AsciiArt
    {
        // Character set from dark → light
        private static readonly char[] asciiChars = { '@', '#', 'S', '%', '?', '*', '+', ';', ':', ',', '.' };

        public static void Display()
        {
            Console.Clear();

            string imagePath = "logo.png"; // Place your PNG in project folder

            if (!File.Exists(imagePath))
            {
                Console.WriteLine("Image not found. Please add 'logo.png' to the project folder.");
                return;
            }

            Bitmap image = new Bitmap(imagePath);

            // Resize image to fit console width
            int width = 100;
            int height = (int)(image.Height * width / (double)image.Width);

            Bitmap resized = new Bitmap(image, new Size(width, height));

            StringBuilder asciiImage = new StringBuilder();

            for (int y = 0; y < resized.Height; y++)
            {
                for (int x = 0; x < resized.Width; x++)
                {
                    Color pixel = resized.GetPixel(x, y);

                    // Convert to grayscale
                    int gray = (pixel.R + pixel.G + pixel.B) / 3;

                    // Map grayscale to ASCII char
                    int index = gray * (asciiChars.Length - 1) / 255;
                    asciiImage.Append(asciiChars[index]);
                }
                asciiImage.AppendLine();
            }

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(asciiImage.ToString());
            Console.ResetColor();
        }
    }
}