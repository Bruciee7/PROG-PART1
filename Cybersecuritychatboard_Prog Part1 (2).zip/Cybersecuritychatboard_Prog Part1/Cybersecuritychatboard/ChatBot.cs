﻿using CybersecurityChatbot;
using System;

namespace CyberSecurityChatBot
{
    /// <summary>
    /// Handles the main chatbot functionality, including user interaction,
    /// input processing, and generating responses.
    /// </summary>
    class ChatBot
    {
        private string Userinput;
        private string userName;

        public ChatBot(string userInput)
        {
            this.Userinput = userInput;
        }

        /// <summary>
        /// Runs the main conversation loop for the chatbot.
        /// </summary>
        public void Run()
        {
            DisplayTopicsMenu();

            while (true)
            {
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Yellow;

                string userInput = Console.ReadLine();
                Console.Write($" [{userInput}] >> ");
                Console.ResetColor();

                // Validates user input and prompts again if no text is entered
                if (string.IsNullOrWhiteSpace(userInput))
                {
                    ConsoleHelper.PrintBotResponse("I didn't recieve any input. Could you please type something?", ConsoleColor.Red);
                    continue;
                }

                userInput = userInput.Trim().ToLower();

                // Checks if the user wants to exit the chatbot
                if (userInput == "exit" || userInput == "quit" || userInput == "bye)")
                {
                    Console.WriteLine();
                    ConsoleHelper.PrintDivider();
                    ConsoleHelper.TypeLine($" Goodbye, {userInput}! Stay safe online.", ConsoleColor.Green);
                    ConsoleHelper.PrintDivider();
                    Console.ResetColor();
                    break;
                }

                // Gets a response from the response engine and displays it
                string response = ResponseEngine.GetResponse(userInput, this.userName);
                ConsoleHelper.PrintBotResponse(response, ConsoleColor.Cyan);
            }
        }

        // Displays a list of topics the user can ask the chatbot about
        private void DisplayTopicsMenu()
        {
            ConsoleHelper.PrintDivider();
            ConsoleHelper.TypeLine("  You can ask me about:", ConsoleColor.Yellow);

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("    • Password Safety");
            Console.WriteLine("    • Phishing Scams");
            Console.WriteLine("    • Safe Browsing");
            Console.WriteLine("    • Suspicious Links");
            Console.WriteLine("    • Malware & Viruses");
            Console.WriteLine("    • Social Engineering & Scams");
            Console.WriteLine("    • How are you?");
            Console.WriteLine("    • What is your purpose?");
            Console.WriteLine("    • Type 'exit' to quit");

            ConsoleHelper.PrintDivider();
            Console.ResetColor();
        }
    }
}